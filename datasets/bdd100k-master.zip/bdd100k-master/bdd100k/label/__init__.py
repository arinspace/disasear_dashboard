"""Format utilities."""
