"""Common functions and utilities."""
